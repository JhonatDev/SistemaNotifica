export const environment = {
    production: false,
    SERVIDOR: "http://localhost:8080"
};
