export const environment = {
    production: true,
    SERVIDOR: "http://52.67.101.241:8080"
};
